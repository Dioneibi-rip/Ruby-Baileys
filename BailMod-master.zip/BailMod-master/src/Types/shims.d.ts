declare module 'link-preview-js';

declare module 'libsignal/src/crypto';
declare module 'libsignal/src/curve';
