import type { Comparable } from '@adiwajshing/keyed-db/lib/Types'
import { calculateObjectSize } from 'bson'
import { CronJob } from 'cron'
import moment from 'moment-timezone'
import type { Db } from 'mongodb'
import type { Logger } from 'pino'
import { proto } from '../../WAProto'
import { DEFAULT_CONNECTION_CONFIG } from '../Defaults'
import type makeMDSocket from '../Socket'
import type {
	BaileysEventEmitter,
	Chat,
	ConnectionState,
	Contact,
	GroupMetadata,
	GroupParticipant,
	PresenceData,
	WAMessage,
	WAMessageCursor,
	WAMessageKey
} from '../Types'
import type { Label } from '../Types/Label'
import {
	type ChatLabelAssociation,
	type LabelAssociation,
	LabelAssociationType,
	type MessageLabelAssociation
} from '../Types/LabelAssociation'
import { md5, toNumber, updateMessageWithReaction, updateMessageWithReceipt } from '../Utils'
import { jidNormalizedUser } from '../WABinary'
import makeOrderedDictionary from './make-ordered-dictionary'
import { ObjectRepository } from './object-repository'

type WASocket = ReturnType<typeof makeMDSocket>

export const waChatKey = (pin: boolean) => ({
	key: (c: Chat) =>
		(pin ? (c.pinned ? '1' : '0') : '') +
		(c.archived ? '0' : '1') +
		(c.conversationTimestamp ? c.conversationTimestamp.toString(16).padStart(8, '0') : '') +
		c.id,
	compare: (k1: string, k2: string) => k2.localeCompare(k1)
})

export const waMessageID = (m: WAMessage) => m.key.id || ''

export const waLabelAssociationKey: Comparable<LabelAssociation, string> = {
	key: (la: LabelAssociation) =>
		la.type === LabelAssociationType.Chat ? la.chatId + la.labelId : la.chatId + la.messageId + la.labelId,
	compare: (k1: string, k2: string) => k2.localeCompare(k1)
}
export type CronJobConfig = {
	/**
	 * Create crontab expressions from https://crontab.guru/
	 */
	cronTime: string | Date
	/**
	 * Timezone of the cron job
	 * @default "Asia/Calcutta"
	 */
	timeZone?: string
	onComplete?: Function
}

export type BaileyesMongoStoreConfig = {
	chatKey?: Comparable<Chat, string>
	labelAssociationKey?: Comparable<LabelAssociation, string>
	socket?: WASocket
	logger?: Logger
	/**
	 * You can set it to not save chats without messages.
	 *
	 * Use this filter to identify unsaved chat types in your current databse.
	 *
	 *     	{ $and: [
	 * 					{ 'messages.message.messageStubType': { $exists: true } },
	 * 					{ 'messages.message.message': { $exists: true } }
	 * 				]
	 * 		}
	 *
	 */
	filterChats?: boolean
	/**
	 * Cron job to delete status message. Set to false to disable
	 *
	 * Deletes all status messages older than 24 hours on At 00:00 (default)
	 * @default config {cronTime: "0 0 * * *", timeZone: "Asia/Calcutta"}
	 */
	autoDeleteStatusMessage: boolean | CronJobConfig
	db: Db
}

const makeMessagesDictionary = () => makeOrderedDictionary(waMessageID)

const predefinedLabels = Object.freeze<Record<string, Label>>({
	'0': {
		id: '0',
		name: 'New customer',
		predefinedId: '0',
		color: 0,
		deleted: false
	},
	'1': {
		id: '1',
		name: 'New order',
		predefinedId: '1',
		color: 1,
		deleted: false
	},
	'2': {
		id: '2',
		name: 'Pending payment',
		predefinedId: '2',
		color: 2,
		deleted: false
	},
	'3': {
		id: '3',
		name: 'Paid',
		predefinedId: '3',
		color: 3,
		deleted: false
	},
	'4': {
		id: '4',
		name: 'Order completed',
		predefinedId: '4',
		color: 4,
		deleted: false
	}
})

export default ({ logger: _logger, socket, db, filterChats, autoDeleteStatusMessage }: BaileyesMongoStoreConfig) => {
	const isOlderThan24Hours = (timestamp: number): boolean => {
		const currentTime = moment(new Date()).tz('Asia/Kolkata')

		const hoursDifference = currentTime.diff(moment(timestamp * 1000).tz('Asia/Kolkata'), 'hours')
		return hoursDifference > 24
	}

	if (autoDeleteStatusMessage) {
		if (typeof autoDeleteStatusMessage === 'boolean') {
			autoDeleteStatusMessage = {
				cronTime: '0 0 * * *',
				timeZone: 'Asia/Calcutta'
			}
		}

		const update = {
			$set: {
				messages: {
					$filter: {
						input: '$messages',
						cond: {
							$not: {
								$or: [] as {
									$eq: Array<string>
								}[]
							}
						}
					}
				}
			}
		}

		new CronJob(
			autoDeleteStatusMessage.cronTime, // cronTime
			async () => {
				const statusMesasges = await chats.findOne({ id: 'status@broadcast' }, { projection: { _id: 0 } })

				if (statusMesasges) {
					for (const m of statusMesasges?.messages!) {
						if (
							isOlderThan24Hours(
								typeof m.message?.messageTimestamp === 'number'
									? m.message?.messageTimestamp
									: (m.message?.messageTimestamp?.low as number)
							)
						) {
							update.$set.messages.$filter.cond.$not.$or.push({
								$eq: ['$$this.message.key.id', m.message?.key?.id as string]
							})
						}
					}

					if (update.$set.messages.$filter.cond.$not.$or.length > 0) {
						const updateResult = await chats.updateOne({ id: 'status@broadcast' }, [update])

						logger?.debug(updateResult, 'updated statusMessages')
					}
				}
			},
			() => {
				logger?.debug('cleared statusMessages')
			},
			true, // start
			autoDeleteStatusMessage?.timeZone
		)
	}

	const logger = _logger || DEFAULT_CONNECTION_CONFIG.logger.child({ stream: 'mongo-store' })

	logger.debug('initializing mongo store')

	// MongoDB document size limits
	const MAX_BSON_DOCUMENT_SIZE_BYTES = 16 * 1024 * 1024 // 16MB
	const WARN_BSON_DOCUMENT_SIZE_BYTES = 15 * 1024 * 1024 // 15MB

	// Estimate BSON document size using BSON calculation for accuracy,
	// with JSON byte-length fallback in case of unexpected serialization issues.
	const approximateDocumentSizeBytes = (doc: unknown): number => {
		try {
			return calculateObjectSize(doc as object, { ignoreUndefined: true })
		} catch {
			try {
				return Buffer.byteLength(JSON.stringify(doc), 'utf8')
			} catch {
				return MAX_BSON_DOCUMENT_SIZE_BYTES
			}
		}
	}

	const chats = db.collection<Chat>('chats')
	const messages: { [_: string]: ReturnType<typeof makeMessagesDictionary> } = {}
	const contacts = db.collection<Contact>('contacts')
	const groupMetadata: { [_: string]: GroupMetadata } = {}
	const presences: { [id: string]: { [participant: string]: PresenceData } } = {}
	const state: ConnectionState = { connection: 'close' }
	const labels = new ObjectRepository<Label>(predefinedLabels)
	const labelAssociations = db.collection<LabelAssociation>('labelAssociations')

	const assertMessageList = (jid: string) => {
		if (!messages[jid]) {
			messages[jid] = makeMessagesDictionary()
		}

		return messages[jid]
	}

	const labelsUpsert = (newLabels: Label[]) => {
		for (const label of newLabels) {
			labels.upsertById(label.id, label)
		}
	}

	// const contactsUpsert = async (newContacts: Contact[]) => {
	// 	const oldContacts = new Set(await contacts
	// 		.find({}, { projection: { _id: 0 } })
	// 		.toArray());

	// 	for (const contact of newContacts) {

	// 	}
	// };

	const bind = (ev: BaileysEventEmitter) => {
		ev.on('connection.update', update => {
			Object.assign(state, update)
		})

		ev.on(
			'messaging-history.set',
			async ({ chats: newChats, contacts: newContacts, messages: newMessages, isLatest }) => {
				if (isLatest) {
					await chats.drop()
					await contacts.drop()
					for (const id in messages) {
						delete messages[id]
					}
				}

				if (filterChats) {
					newChats = newChats
						.map(chat => {
							if (chat.messages?.some(m => !m.message?.message && m.message?.messageStubType)) {
								return undefined
							}

							return chat
						})
						.filter(Boolean) as Chat[]
				}

				if (newChats.length) {
					const chatsAdded = await chats.bulkWrite(
						newChats.map(chat => {
							return {
								insertOne: {
									document: chat
								}
							}
						})
					)

					logger.debug({ chatsAdded: chatsAdded.insertedCount }, 'synced chats')
				} else {
					logger.debug('no chats added')
				}

				if (newContacts.length) {
					const oldContacts = await contacts.bulkWrite(
						newContacts.map(contact => {
							return {
								insertOne: {
									document: contact
								}
							}
						})
					)
					logger.debug({ insertedContacts: oldContacts.insertedCount }, 'synced contacts')

					if (!oldContacts.insertedCount) {
						throw new Error('no contacts added')
					}
				} else {
					logger.debug('no contacts to sync')
				}

				for (const msg of newMessages) {
					const jid = msg.key.remoteJid!
					const list = assertMessageList(jid)
					list.upsert(msg, 'prepend')

					const chat = await chats.findOne({ id: jid }, { projection: { _id: 0 } })

					if (chat) {
						chat.messages?.push({ message: msg }) || (chat.messages = [{ message: msg }])
						await chats.findOneAndUpdate({ id: jid }, { $set: chat }, { upsert: true })
					} else {
						logger.debug({ jid }, 'chat not found')
					}
				}

				logger.debug({ messages: newMessages.length }, 'synced messages')
			}
		)

		ev.on('contacts.upsert', async Contacts => {
			if (!Contacts?.length) {
				logger?.debug('no contacts to upsert')
				return
			}

			const operations = Contacts.map(contact => ({
				updateOne: {
					filter: { id: contact.id },
					update: { $set: contact },
					upsert: true
				}
			}))

			try {
				const result = await contacts.bulkWrite(operations)
				logger?.debug(
					{
						contactsUpserted: result.upsertedCount,
						contactsModified: result.modifiedCount,
						contactsMatched: result.matchedCount
					},
					'contacts upserted'
				)
			} catch (error) {
				logger?.error({ error, contactsCount: Contacts.length }, 'error during contacts bulkWrite')
			}
		})

		ev.on('contacts.update', async updates => {
			for (const update of updates) {
				const contact: Partial<Contact> | null = await contacts.findOne({ id: update.id }, { projection: { _id: 0 } })

				if (contact) {
					Object.assign(contact, update)
					await contacts.updateOne({ id: update.id }, { $set: contact }, { upsert: true })
				} else {
					logger.debug('got update for non-existent contact')
				}
			}
		})

		ev.on('chats.upsert', async newChats => {
			if (!newChats?.length) {
				logger.debug('no chats to upsert')
				return
			}

			await chats.bulkWrite(
				newChats.map(chat => {
					return {
						updateOne: {
							filter: { id: chat.id },
							update: { $set: chat },
							upsert: true
						}
					}
				})
			)
		})

		ev.on('chats.update', async updates => {
			// try {
			if (!updates?.length) {
				logger.debug('no chats to update')
				return
			}

			const operations = updates.map(update => ({
				updateOne: {
					filter: { id: update.id },
					update: { $set: update },
					upsert: true
				}
			}))

			// for (const update of updates) {
			// 	const chat = await chats.findOneAndUpdate(
			// 		{ id: update.id },
			// 		{
			// 			$set: update
			// 		},
			// 		{ upsert: true }
			// 	)

			// 	if (!chat) {
			// 		logger.debug('got update for non-existant chat')
			// 	}
			// }

			try {
				const result = await chats.bulkWrite(operations)
				logger.debug(
					{
						chatsUpserted: result.upsertedCount,
						chatsModified: result.modifiedCount,
						chatsMatched: result.matchedCount
					},
					'chats updated'
				)
			} catch (error) {
				logger.error({ error, updatesCount: updates.length }, 'error during chats bulkWrite')
			}
		})

		ev.on('labels.edit', (label: Label) => {
			if (label.deleted) {
				return labels.deleteById(label.id)
			}

			// WhatsApp can store only up to 20 labels
			if (labels.count() < 20) {
				return labels.upsertById(label.id, label)
			}

			logger.error('Labels count exceed')
		})

		ev.on('labels.association', async ({ type, association }) => {
			switch (type) {
				case 'add':
					await labelAssociations.updateOne(
						{ id: association?.chatId || association?.labelId },
						{ $set: association },
						{ upsert: true }
					)
					break
				case 'remove':
					await labelAssociations.deleteOne({
						id: association?.chatId || association?.labelId
					})
					break
				default:
					logger.error(`unknown operation type [${type}]`)
			}
		})

		ev.on('presence.update', ({ id, presences: update }) => {
			presences[id] = presences[id] || {}
			Object.assign(presences[id], update)
		})

		ev.on('chats.delete', async deletions => {
			for (const item of deletions) {
				await chats.deleteOne({ id: item })
			}
		})

		ev.on('messages.upsert', async ({ messages: newMessages, type }) => {
			// try {
			switch (type) {
				case 'append':
				case 'notify':
					for (const msg of newMessages) {
						const jid = jidNormalizedUser(msg.key.remoteJid!)
						const list = assertMessageList(jid)
						list.upsert(msg, 'append')

						const chat = await chats.findOne({ id: jid })
						if (type === 'notify') {
							if (!chat) {
								ev.emit('chats.upsert', [
									{
										id: jid,
										conversationTimestamp: toNumber(msg.messageTimestamp),
										unreadCount: 1
									}
								])
							} else {
								chat.messages ? chat.messages.push({ message: msg }) : (chat.messages = [{ message: msg }])
								const sizeBytes = approximateDocumentSizeBytes(chat)
								if (sizeBytes >= MAX_BSON_DOCUMENT_SIZE_BYTES) {
									// Revert the push to avoid persisting an oversized document
									chat.messages?.pop()
									logger?.error({ jid, sizeBytes }, 'refusing to update chat; document would exceed MongoDB 16MB limit')
									continue
								}

								if (sizeBytes >= WARN_BSON_DOCUMENT_SIZE_BYTES) {
									logger?.warn({ jid, sizeBytes }, 'chat document size approaching MongoDB 16MB limit')
								}

								await chats.updateOne({ id: jid }, { $set: chat }, { upsert: true })
							}
						}
					}

					break
			}
		})

		ev.on('messages.update', updates => {
			for (const { update, key } of updates) {
				const list = assertMessageList(jidNormalizedUser(key.remoteJid!))
				if (update?.status) {
					const listStatus = list.get(key.id!)?.status
					if (listStatus && update?.status <= listStatus) {
						logger.debug({ update, storedStatus: listStatus }, 'status stored newer then update')
						delete update.status
						logger.debug({ update }, 'new update object')
					}
				}

				const result = list.updateAssign(key.id!, update)
				if (!result) {
					logger.debug('got update for non-existent message')
				}
			}
		})

		ev.on('messages.delete', item => {
			if ('all' in item) {
				const list = messages[item.jid]
				list?.clear()
			} else {
				const jid = item.keys[0]?.remoteJid as string
				const list = messages[jid]
				if (list) {
					const idSet = new Set(item.keys.map(k => k.id))
					list.filter(m => !idSet.has(m.key.id))
				}
			}
		})

		ev.on('groups.update', updates => {
			for (const update of updates) {
				const id = update.id!
				if (groupMetadata[id]) {
					Object.assign(groupMetadata[id], update)
				} else {
					logger.debug({ update }, 'got update for non-existant group metadata')
				}
			}
		})

		ev.on('group-participants.update', ({ id, participants, action }) => {
			const metadata = groupMetadata[id]
			if (metadata) {
				switch (action) {
					case 'add':
						metadata.participants.push(
							...(participants.map(p => ({
								...p,
								id: p.id,
								isAdmin: false,
								isSuperAdmin: false
							})) as GroupParticipant[])
						)
						break
					case 'demote':
					case 'promote':
						for (const participant of metadata.participants) {
							if (participants.some(p => p.id === participant.id)) {
								participant.isAdmin = action === 'promote'
							}
						}

						break
					case 'remove':
						metadata.participants = metadata.participants.filter(p => !participants.some(p2 => p2.id === p.id))
						break
				}
			}
		})

		ev.on('message-receipt.update', updates => {
			for (const { key, receipt } of updates) {
				const obj = messages[key.remoteJid!]
				const msg = obj?.get(key.id!)
				if (msg) {
					updateMessageWithReceipt(msg, receipt)
				}
			}
		})

		ev.on('messages.reaction', reactions => {
			for (const { key, reaction } of reactions) {
				const obj = messages[key.remoteJid!]
				const msg = obj?.get(key.id!)
				if (msg) {
					updateMessageWithReaction(msg, reaction)
				}
			}
		})
	}

	const toJSON = () => ({
		chats,
		contacts,
		messages,
		labels,
		labelAssociations
	})

	// TODO: replace upsert logic by corresponding mongodb collection methods
	const fromJSON = async (json: {
		chats: Chat[]
		contacts: { [id: string]: Contact }
		messages: { [id: string]: WAMessage[] }
		labels: { [labelId: string]: Label }
		labelAssociations: LabelAssociation[]
	}) => {
		await chats.updateMany({}, { $set: { ...json.chats } }, { upsert: true })
		await labelAssociations.updateMany({}, { $set: { ...(json.labelAssociations || []) } }, { upsert: true })

		const contactsCollection = db.collection<Contact>('contacts')
		await contactsCollection.updateMany({}, { $set: { ...Object.values(json.contacts) } }, { upsert: true })
		//
		// contactsUpsert(Object.values(json.contacts))
		labelsUpsert(Object.values(json.labels || {}))
		for (const jid in json.messages) {
			const list = assertMessageList(jid)
			for (const msg of json.messages[jid] || []) {
				list.upsert(proto.WebMessageInfo.fromObject(msg) as unknown as WAMessage, 'append')
			}
		}
	}

	/**
	 * Retrieves a chat object by its ID.
	 *
	 * @param {string} jid - The ID of the chat.
	 * @return {Promise<Chat|null>} A promise that resolves to the chat object if found, or null if not found.
	 */
	const getChatById = async (jid: string): Promise<Chat | null> => {
		return await chats.findOne({ id: jid }, { projection: { _id: 0 } })
	}

	/**
	 * Calculates approximate BSON size in bytes for a chat document.
	 * Note: This is an estimate based on JSON byte length and may differ
	 * slightly from actual BSON size used by MongoDB.
	 */
	const getChatSizeBytes = async (jid: string): Promise<number> => {
		// include _id in the calculation to reflect actual stored document size
		const chat = await chats.findOne({ id: jid })
		return chat ? approximateDocumentSizeBytes(chat) : 0
	}

	return {
		chats,
		contacts,
		messages,
		groupMetadata,
		state,
		presences,
		labels,
		labelAssociations,
		bind,
		/** loads messages from the store, if not found -- uses the legacy connection */
		loadMessages: async (jid: string, count: number, cursor: WAMessageCursor) => {
			const list = assertMessageList(jid)
			const mode = !cursor || 'before' in cursor ? 'before' : 'after'
			const cursorKey = !!cursor ? ('before' in cursor ? cursor.before : cursor.after) : undefined
			const cursorValue = cursorKey ? list.get(cursorKey.id!) : undefined

			let messages: WAMessage[]
			if (list && mode === 'before' && (!cursorKey || cursorValue)) {
				if (cursorValue) {
					const msgIdx = list.array.findIndex(m => m.key.id === cursorKey?.id)
					messages = list.array.slice(0, msgIdx)
				} else {
					messages = list.array
				}

				const diff = count - messages.length
				if (diff < 0) {
					messages = messages.slice(-count) // get the last X messages
				}
			} else {
				messages = []
			}

			return messages
		},
		/**
		 * Get all available labels for profile
		 *
		 * Keep in mind that the list is formed from predefined tags and tags
		 * that were "caught" during their editing.
		 */
		getLabels: () => {
			return labels
		},

		/**
		 * Get labels for chat
		 *
		 * @returns Label IDs
		 **/
		getChatLabels: (chatId: string) => {
			return labelAssociations.findOne((la: { chatId: string }) => la.chatId === chatId)
		},

		/**
		 * Get labels for message
		 *
		 * @returns Label IDs
		 **/
		getMessageLabels: async (messageId: string) => {
			const associations = labelAssociations.find((la: MessageLabelAssociation | ChatLabelAssociation) =>
				'messageId' in la ? la.messageId === messageId : la.chatId === messageId
			)

			return associations?.map(({ labelId }) => labelId)
		},
		loadMessage: async (jid: string, id: string) => {
			if (messages[jid]) {
				return messages[jid].get(id)
			}

			const chat = await chats.findOne({ id: jid }, { projection: { _id: 0 } })
			for (const m of chat?.messages ?? []) {
				if (m?.message?.key?.id === id) {
					return m.message
				}
			}
		},
		mostRecentMessage: async (jid: string) => {
			const message: WAMessage | proto.IWebMessageInfo | undefined =
				messages[jid]?.array.slice(-1)[0] ||
				((await chats.findOne({ id: jid }, { projection: { _id: 0 } }))?.messages?.slice(-1)[0]?.message as
					| WAMessage
					| proto.IWebMessageInfo
					| undefined) ||
				undefined
			return message as WAMessage | undefined
		},
		fetchImageUrl: async (jid: string, sock: WASocket | undefined) => {
			const contact = await contacts.findOne({ id: jid }, { projection: { _id: 0 } })
			if (!contact) {
				return sock?.profilePictureUrl(jid)
			}

			if (typeof contact.imgUrl === 'undefined') {
				contact.imgUrl = await sock?.profilePictureUrl(jid)
				await contacts.updateOne({ id: jid }, { $set: contact }, { upsert: true })
			}

			return contact.imgUrl
		},
		getContactInfo: async (jid: string, socket: WASocket): Promise<Partial<Contact> | null> => {
			const contact: Partial<Contact> | null = await contacts.findOne({ id: jid }, { projection: { _id: 0 } })

			if (!contact) {
				return {
					id: jid,
					imgUrl: await socket?.profilePictureUrl(jid)
				}
			}

			// fetch image if required
			if (typeof contact.imgUrl === 'undefined' || contact.imgUrl === 'changed') {
				contact.imgUrl = await socket?.profilePictureUrl(contact.id!, 'image')
				await contacts.updateOne({ id: jid }, { $set: { ...contact } }, { upsert: true })
			}

			return contact
		},
		fetchGroupMetadata: async (jid: string, sock: WASocket | undefined) => {
			if (!groupMetadata[jid]) {
				const metadata = await sock?.groupMetadata(jid)
				if (metadata) {
					groupMetadata[jid] = metadata
				}
			}

			return groupMetadata[jid]
		},

		fetchMessageReceipts: async ({ remoteJid, id }: WAMessageKey) => {
			const list = messages[remoteJid!]
			const msg = list?.get(id!)
			return msg?.userReceipt
		},
		getChatById,
		getChatSizeBytes,
		toJSON,
		fromJSON
	}
}
