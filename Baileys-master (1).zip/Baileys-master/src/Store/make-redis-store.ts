// dumb hack
import KeyedDB from '@adiwajshing/keyed-db'
import type { Comparable } from '@adiwajshing/keyed-db/lib/Types'
import type { Logger } from 'pino'
import { createClient } from 'redis'
import { proto } from '../../WAProto'
import { DEFAULT_CONNECTION_CONFIG } from '../Defaults'
import type makeMDSocket from '../Socket'
import type {
	BaileysEventEmitter,
	Chat,
	ConnectionState,
	Contact,
	GroupMetadata,
	GroupParticipant,
	PresenceData,
	WAMessage,
	WAMessageCursor,
	WAMessageKey
} from '../Types'
import { type Label } from '../Types/Label'
import {
	type ChatLabelAssociation,
	type LabelAssociation,
	LabelAssociationType,
	type MessageLabelAssociation
} from '../Types/LabelAssociation'
import { BufferJSON, toNumber, updateMessageWithReaction, updateMessageWithReceipt } from '../Utils'
import { jidNormalizedUser } from '../WABinary'
import makeOrderedDictionary from './make-ordered-dictionary'
import { ObjectRepository } from './object-repository'

type WASocket = ReturnType<typeof makeMDSocket>

export const waChatKey = (pin: boolean) => ({
	key: (c: Chat) =>
		(pin ? (c.pinned ? '1' : '0') : '') +
		(c.archived ? '0' : '1') +
		(c.conversationTimestamp ? c.conversationTimestamp.toString(16).padStart(8, '0') : '') +
		c.id,
	compare: (k1: string, k2: string) => k2.localeCompare(k1)
})

export const waMessageID = (m: WAMessage) => m.key.id || ''

export const waLabelAssociationKey: Comparable<LabelAssociation, string> = {
	key: (la: LabelAssociation) =>
		la.type === LabelAssociationType.Chat ? la.chatId + la.labelId : la.chatId + la.messageId + la.labelId,
	compare: (k1: string, k2: string) => k2.localeCompare(k1)
}

export type BaileysInMemoryStoreConfig = {
	chatKey?: Comparable<Chat, string>
	labelAssociationKey?: Comparable<LabelAssociation, string>
	logger?: Logger
	redis: ReturnType<typeof createClient>
	suffix?: string
}

const makeMessagesDictionary = () => makeOrderedDictionary(waMessageID)

const predefinedLabels = Object.freeze<Record<string, Label>>({
	'0': {
		id: '0',
		name: 'New customer',
		predefinedId: '0',
		color: 0,
		deleted: false
	},
	'1': {
		id: '1',
		name: 'New order',
		predefinedId: '1',
		color: 1,
		deleted: false
	},
	'2': {
		id: '2',
		name: 'Pending payment',
		predefinedId: '2',
		color: 2,
		deleted: false
	},
	'3': {
		id: '3',
		name: 'Paid',
		predefinedId: '3',
		color: 3,
		deleted: false
	},
	'4': {
		id: '4',
		name: 'Order completed',
		predefinedId: '4',
		color: 4,
		deleted: false
	}
})

export default ({ logger: _logger, chatKey, labelAssociationKey, redis, suffix }: BaileysInMemoryStoreConfig) => {
	chatKey = chatKey || waChatKey(true)
	labelAssociationKey = labelAssociationKey || waLabelAssociationKey
	suffix = suffix || 'store'
	const logger = _logger || DEFAULT_CONNECTION_CONFIG.logger.child({ stream: 'redis:store' })

	const chats = new KeyedDB(chatKey, c => c.id!)
	const messages: { [_: string]: ReturnType<typeof makeMessagesDictionary> } = {}
	const contacts: { [_: string]: Contact } = {}
	const groupMetadata: { [_: string]: GroupMetadata } = {}
	const presences: { [id: string]: { [participant: string]: PresenceData } } = {}
	const state: ConnectionState = { connection: 'close' }
	const labels = new ObjectRepository<Label>(predefinedLabels)
	const labelAssociations = new KeyedDB(labelAssociationKey, labelAssociationKey.key)

	const assertMessageList = (jid: string) => {
		if (!messages[jid]) {
			messages[jid] = makeMessagesDictionary()
		}

		return messages[jid]
	}

	const contactsUpsert = (newContacts: Contact[]) => {
		const oldContacts = new Set(Object.keys(contacts))
		for (const contact of newContacts) {
			oldContacts.delete(contact.id)
			contacts[contact.id] = Object.assign(contacts[contact.id] || {}, contact)
		}

		return oldContacts
	}

	const labelsUpsert = (newLabels: Label[]) => {
		for (const label of newLabels) {
			labels.upsertById(label.id, label)
		}
	}

	/**
	 * binds to a BaileysEventEmitter.
	 * It listens to all events and constructs a state that you can query accurate data from.
	 * Eg. can use the store to fetch chats, contacts, messages etc.
	 * @param ev typically the event emitter from the socket connection
	 */
	const bind = (ev: BaileysEventEmitter) => {
		ev.on('connection.update', update => {
			Object.assign(state, update)
		})

		ev.on('messaging-history.set', ({ chats: newChats, contacts: newContacts, messages: newMessages, isLatest }) => {
			if (isLatest) {
				chats.clear()

				for (const id in messages) {
					delete messages[id]
				}
			}

			const chatsAdded = chats.insertIfAbsent(...newChats).length
			logger.debug({ chatsAdded }, 'synced chats')

			const oldContacts = contactsUpsert(newContacts)
			if (isLatest) {
				for (const jid of oldContacts) {
					delete contacts[jid]
				}
			}

			logger.debug({ deletedContacts: isLatest ? oldContacts.size : 0, newContacts }, 'synced contacts')

			for (const msg of newMessages) {
				const jid = msg.key.remoteJid!
				const list = assertMessageList(jid)
				list.upsert(msg, 'prepend')
			}

			logger.debug({ messages: newMessages.length }, 'synced messages')
		})

		ev.on('contacts.upsert', contacts => {
			contactsUpsert(contacts)
		})

		ev.on('contacts.update', updates => {
			for (const update of updates) {
				if (update.id && contacts[update.id]) {
					Object.assign(contacts[update.id] as Contact, update)
				} else {
					logger.debug({ update }, 'got update for non-existant contact')
				}
			}
		})
		ev.on('chats.upsert', newChats => {
			chats.upsert(...newChats)
		})
		ev.on('chats.update', updates => {
			for (let update of updates) {
				const result = chats.update(update.id!, chat => {
					if (update.unreadCount! > 0) {
						update = { ...update }
						update.unreadCount = (chat.unreadCount || 0) + update.unreadCount!
					}

					Object.assign(chat, update)
				})
				if (!result) {
					logger.debug({ update }, 'got update for non-existant chat')
				}
			}
		})

		ev.on('labels.edit', (label: Label) => {
			if (label.deleted) {
				return labels.deleteById(label.id)
			}

			// WhatsApp can store only up to 20 labels
			if (labels.count() < 20) {
				return labels.upsertById(label.id, label)
			}

			logger.error('Labels count exceed')
		})

		ev.on('labels.association', ({ type, association }) => {
			switch (type) {
				case 'add':
					labelAssociations.upsert(association)
					break
				case 'remove':
					labelAssociations.delete(association)
					break
				default:
					logger.error(`unknown operation type [${type}]`)
			}
		})

		ev.on('presence.update', ({ id, presences: update }) => {
			presences[id] = presences[id] || {}
			Object.assign(presences[id], update)
		})
		ev.on('chats.delete', deletions => {
			for (const item of deletions) {
				if (chats.get(item)) {
					chats.deleteById(item)
				}
			}
		})
		ev.on('messages.upsert', ({ messages: newMessages, type }) => {
			switch (type) {
				case 'append':
				case 'notify':
					for (const msg of newMessages) {
						const jid = jidNormalizedUser(msg.key.remoteJid!)
						const list = assertMessageList(jid)
						list.upsert(msg, 'append')

						if (type === 'notify') {
							if (!chats.get(jid)) {
								ev.emit('chats.upsert', [
									{
										id: jid,
										conversationTimestamp: toNumber(msg.messageTimestamp),
										unreadCount: 1
									}
								])
							}
						}
					}

					break
			}
		})
		ev.on('messages.update', updates => {
			for (const { update, key } of updates) {
				const list = assertMessageList(jidNormalizedUser(key.remoteJid!))
				if (update?.status) {
					const listStatus = list.get(key.id!)?.status
					if (listStatus && update?.status <= listStatus) {
						logger.debug({ update, storedStatus: listStatus }, 'status stored newer then update')
						delete update.status
						logger.debug({ update }, 'new update object')
					}
				}

				const result = list.updateAssign(key.id!, update)
				if (!result) {
					logger.debug({ update }, 'got update for non-existent message')
				}
			}
		})
		ev.on('messages.delete', item => {
			if ('all' in item) {
				const list = messages[item.jid]
				list?.clear()
			} else {
				const jid = item.keys[0]?.remoteJid as string
				const list = messages[jid]
				if (list) {
					const idSet = new Set(item.keys.map(k => k.id))
					list.filter(m => !idSet.has(m.key.id))
				}
			}
		})

		ev.on('groups.update', updates => {
			for (const update of updates) {
				const id = update.id!
				if (groupMetadata[id]) {
					Object.assign(groupMetadata[id], update)
				} else {
					logger.debug({ update }, 'got update for non-existant group metadata')
				}
			}
		})

		ev.on('group-participants.update', ({ id, participants, action }) => {
			const metadata = groupMetadata[id]
			if (metadata) {
				switch (action) {
					case 'add':
						metadata.participants.push(
							...(participants.map(p => ({
								...p,
								id: p.id,
								isAdmin: false,
								isSuperAdmin: false
							})) as GroupParticipant[])
						)
						break
					case 'demote':
					case 'promote':
						for (const participant of metadata.participants) {
							if (participants.some(p => p.id === participant.id)) {
								participant.isAdmin = action === 'promote'
							}
						}

						break
					case 'remove':
						metadata.participants = metadata.participants.filter(p => !participants.some(p2 => p2.id === p.id))
						break
				}
			}
		})

		ev.on('message-receipt.update', updates => {
			for (const { key, receipt } of updates) {
				const obj = messages[key.remoteJid!]
				const msg = obj?.get(key.id!)
				if (msg) {
					updateMessageWithReceipt(msg, receipt)
				}
			}
		})

		ev.on('messages.reaction', reactions => {
			for (const { key, reaction } of reactions) {
				const obj = messages[key.remoteJid!]
				const msg = obj?.get(key.id!)
				if (msg) {
					updateMessageWithReaction(msg, reaction)
				}
			}
		})
	}

	const toJSON = () => ({
		chats,
		contacts,
		messages,
		labels,
		labelAssociations
	})

	const fromJSON = (json: {
		chats: Chat[]
		contacts: { [id: string]: Contact }
		messages: { [id: string]: WAMessage[] }
		labels: { [labelId: string]: Label }
		labelAssociations: LabelAssociation[]
	}) => {
		chats.upsert(...json.chats)
		labelAssociations.upsert(...(json.labelAssociations || []))
		contactsUpsert(Object.values(json.contacts))
		labelsUpsert(Object.values(json.labels || {}))
		for (const jid in json.messages) {
			const list = assertMessageList(jid)
			for (const msg of json.messages[jid] || []) {
				list.upsert(proto.WebMessageInfo.fromObject(msg) as unknown as WAMessage, 'append')
			}
		}
	}

	return {
		chats,
		contacts,
		messages,
		groupMetadata,
		state,
		presences,
		labels,
		labelAssociations,
		bind,
		/** loads messages from the store, if not found -- uses the legacy connection */
		loadMessages: async (jid: string, count: number, cursor: WAMessageCursor) => {
			const list = assertMessageList(jid)
			const mode = !cursor || 'before' in cursor ? 'before' : 'after'
			const cursorKey = !!cursor ? ('before' in cursor ? cursor.before : cursor.after) : undefined
			const cursorValue = cursorKey ? list.get(cursorKey.id!) : undefined

			let messages: WAMessage[]
			if (list && mode === 'before' && (!cursorKey || cursorValue)) {
				if (cursorValue) {
					const msgIdx = list.array.findIndex(m => m.key.id === cursorKey?.id)
					messages = list.array.slice(0, msgIdx)
				} else {
					messages = list.array
				}

				const diff = count - messages.length
				if (diff < 0) {
					messages = messages.slice(-count) // get the last X messages
				}
			} else {
				messages = []
			}

			return messages
		},
		/**
		 * Get all available labels for profile
		 *
		 * Keep in mind that the list is formed from predefined tags and tags
		 * that were "caught" during their editing.
		 */
		getLabels: () => {
			return labels
		},

		/**
		 * Get labels for chat
		 *
		 * @returns Label IDs
		 **/
		getChatLabels: (chatId: string) => {
			return labelAssociations.filter(la => la.chatId === chatId).all()
		},
		getContactInfo: async (chatId: string) => {
			const contacts = await redis.hGet(`contacts:${suffix}`, chatId)
			return contacts ? (JSON.parse(contacts, BufferJSON.reviver) as Contact) : null
		},
		/**
		 * Get labels for message
		 *
		 * @returns Label IDs
		 **/
		getMessageLabels: (messageId: string) => {
			const associations = labelAssociations
				.filter((la: MessageLabelAssociation | ChatLabelAssociation) =>
					'messageId' in la ? la.messageId === messageId : la.chatId === messageId
				)
				.all()

			return associations.map(({ labelId }) => labelId)
		},
		loadMessage: async (jid: string, id: string) => messages[jid]?.get(id),
		mostRecentMessage: async (jid: string) => {
			const message: WAMessage | proto.IWebMessageInfo | undefined = messages[jid]?.array.slice(-1)[0]
			return message as WAMessage | undefined
		},
		fetchImageUrl: async (jid: string, sock: WASocket | undefined) => {
			const contact = contacts[jid]
			if (!contact) {
				return sock?.profilePictureUrl(jid)
			}

			if (typeof contact.imgUrl === 'undefined') {
				contact.imgUrl = await sock?.profilePictureUrl(jid)
			}

			return contact.imgUrl
		},
		fetchGroupMetadata: async (jid: string, sock: WASocket | undefined) => {
			if (!groupMetadata[jid]) {
				const metadata = await sock?.groupMetadata(jid)
				if (metadata) {
					groupMetadata[jid] = metadata
				}
			}

			return groupMetadata[jid]
		},
		// fetchBroadcastListInfo: async(jid: string, sock: WASocket | undefined) => {
		// 	if(!groupMetadata[jid]) {
		// 		const metadata = await sock?.getBroadcastListInfo(jid)
		// 		if(metadata) {
		// 			groupMetadata[jid] = metadata
		// 		}
		// 	}

		// 	return groupMetadata[jid]
		// },
		fetchMessageReceipts: async ({ remoteJid, id }: WAMessageKey) => {
			const list = messages[remoteJid!]
			const msg = list?.get(id!)
			return msg?.userReceipt
		},
		toJSON,
		fromJSON,
		uploadToDb: async () => {
			if (!redis.isReady) {
				await redis.connect()
			}

			const jsonData = toJSON()

			for (const key of Object.keys(jsonData) as Array<keyof typeof jsonData>) {
				const data = jsonData[key]
				const suffixKey = `${key}:${suffix}`

				switch (key) {
					case 'chats':
						// @ts-ignore
						for (const chat of data.array as unknown as Chat[]) {
							await redis.hSet(suffixKey, chat.id!, JSON.stringify(chat, BufferJSON.replacer))
						}

						break

					case 'contacts':
						for (const contact of Object.values(data) as unknown as Contact[]) {
							await redis.hSet(suffixKey, contact.id, JSON.stringify(contact, BufferJSON.replacer))
						}

						break

					case 'messages':
						for (const msgKey of Object.keys(data as unknown as Record<string, WAMessage[]>)) {
							await redis.hSet(
								suffixKey,
								msgKey,
								JSON.stringify(data[msgKey as keyof typeof data], BufferJSON.replacer)
							)
						}

						break

					case 'labelAssociations':
					case 'labels':
						await redis.set(suffixKey, JSON.stringify(data, BufferJSON.replacer))
						break
				}
			}
		},
		readFromDb: async () => {
			if (!redis.isReady) {
				await redis.connect()
			}

			const jsonObject = {
				chats: [] as Chat[],
				contacts: {} as { [id: string]: Contact },
				messages: {} as { [id: string]: WAMessage[] },
				labels: {} as { [labelId: string]: Label },
				labelAssociations: [] as LabelAssociation[]
			}

			const readObjectFromDb = async (key: string) => {
				const tempObj = await redis.hGetAll(`${key}:${suffix}`)
				const parsedObj = Object.keys(tempObj).map(id => JSON.parse(tempObj[id] as string, BufferJSON.reviver))
				// @ts-ignore
				jsonObject[key] = parsedObj
			}

			const readArrayFromDb = async (key: string) => {
				const parsedArray = JSON.parse((await redis.get(`${key}:${suffix}`)) || '[]', BufferJSON.reviver)
				// @ts-ignore
				jsonObject[key] = parsedArray
			}

			await Promise.all([
				readObjectFromDb('chats'),
				readObjectFromDb('contacts'),
				readObjectFromDb('messages'),
				readArrayFromDb('labels'),
				readArrayFromDb('labelAssociations')
			])

			fromJSON(jsonObject)
		}
	}
}
